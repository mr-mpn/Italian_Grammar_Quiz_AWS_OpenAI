from openai.api_resources.experimental.completion_config import (  # noqa: F401
    CompletionConfig,
)
